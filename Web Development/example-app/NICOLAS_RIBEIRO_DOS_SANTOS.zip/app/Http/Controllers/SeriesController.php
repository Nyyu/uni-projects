<?php

namespace App\Http\Controllers;

use App\Models\Series;
use Illuminate\Http\Request;

class SeriesController extends Controller
{

    function list() {
        $series = Series::all();
        // return $series;
        return view("series.index", compact('series'));
    }

    public function create()
    {
        return view("series.create");
    }

    public function store(Request $request)
    {
        $name = $request->name;

        $Series = new Series();
        $Series->name = $name;
        $Series->save();

        $series = Series::all();
        return view("series.index", compact('series'));
    }
}
