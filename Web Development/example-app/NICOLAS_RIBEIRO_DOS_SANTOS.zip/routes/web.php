<?php

use App\Http\Controllers\CarrosController;
use App\Http\Controllers\DisciplinasController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LivrosController;
use App\Http\Controllers\ProductsController;
use App\Http\Controllers\SeriesController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

// Simple route
Route::get('/', function () {return view('welcome');});
// Optional parameter
Route::get('/test/{temp?}', null);

// Using controller
Route::get('/home', HomeController::class);

// Using secondary function inside the controller
Route::get('/home2', [HomeController::class, 'principal']);

Route::get('/series/list', [SeriesController::class, 'list']);
Route::get('/series/create', [SeriesController::class, 'create']);
Route::post('/series/create', [SeriesController::class, 'store']);

Route::get('/products/list', [ProductsController::class, 'list']);
Route::get('/products/create', [ProductsController::class, 'create']);
Route::post('/products/create', [ProductsController::class, 'store']);

Route::get('/livros/listar', LivrosController::class);

Route::get('/carros/listar', CarrosController::class);

Route::get('/disciplinas/listar', DisciplinasController::class);
